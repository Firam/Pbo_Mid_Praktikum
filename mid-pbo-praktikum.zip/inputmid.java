class inputmid {
	protected char merek, tipe;
	protected int jumlah;
	
	public void setMerek(char merek){
		this.merek=merek;
	}
	
	public void setTipe(char tipe){
		this.tipe=tipe;
	}
	
	public void setJumlah(int jumlah){
		this.jumlah=jumlah;
	}
}